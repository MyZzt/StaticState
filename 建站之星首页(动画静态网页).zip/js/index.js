//让广告删除 
function del1(){
	let New1=document.getElementById('News');
	News.parentNode.removeChild(News)
}
//网页刷新后自动回到顶部
addEventListener("load", function(){ 
  setTimeout(hideURLbar, 0); 
}, false); 
function hideURLbar(){ 
  window.scrollTo(0,1); 
}